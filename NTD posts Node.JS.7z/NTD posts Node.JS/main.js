var output = [];
var output_details = [];
var output_other = [];
var output_other_details = [];
var output_human_date = [];
var output_full_details = [];
var output_max_value = [];
var output_max_values = [];
var count = 0
var count_other = 0;

var csv = require('csv');
var obj = csv();
var objDetails = csv();
var objOther = csv();
var objOtherDetails = csv();
var objDailyTopPosts = csv();
var fs = require('fs');
var unique = require('array-unique');
var datetime = require('node-datetime');

var lineReader = require('readline').createInterface({	
  input: require('fs').createReadStream('./posts.csv', 'utf8')
});

lineReader.on('line', function (line) {
    var jsonFromLine = {};
	var jsonFromLineDetails = {};
	var jsonFromLineDate = {};
    var lineSplit = line.split(',');
    jsonFromLineDetails.id = lineSplit[0];
    jsonFromLineDetails.title = lineSplit[1];
	jsonFromLineDetails.privacy = lineSplit[2];
	jsonFromLineDetails.likes = lineSplit[3];
	jsonFromLineDetails.views = lineSplit[4];
	jsonFromLineDetails.comments = lineSplit[5];
	jsonFromLineDetails.timestamp = lineSplit[6];	
	jsonFromLine.id = lineSplit[0];
	jsonFromLineDate = lineSplit[6];
	
    if (jsonFromLineDetails.privacy === 'public' && 
	    (jsonFromLineDetails.comments > 10 && jsonFromLineDetails.views > 9000) &&
		jsonFromLineDetails.title.length < 40 ) 
		{
			output.push(jsonFromLine);	
			output_details.push(jsonFromLineDetails);
			count++;
		}
		
	if (jsonFromLineDetails.privacy !== 'public' || 
	    (jsonFromLineDetails.comments <= 10 || jsonFromLineDetails.views <= 9000) ||
		jsonFromLineDetails.title.length >= 40 ) {
			output_other.push(jsonFromLine);
			output_other_details.push(jsonFromLineDetails);
			count_other++
		}
		
		output_full_details.push(jsonFromLineDetails);
		var human_date = String(datetime.create(lineSplit[6]).format('Y-m-d'));		
		if (human_date.search('2015') == 0) {
			output_human_date.push(human_date);
		}		
		unique(output_human_date);
}); 

lineReader.on('close', function (line) {
    console.log(output); // list output	
	obj.from.array(output).to.path('./results/top_posts.csv'); 
	
	fs.writeFile("./results/top_posts.json", JSON.stringify(output), function(err) {
    if (err) throw err;
    console.log('complete');
    });
	
	console.log(output_details); // list output details
	objDetails.from.array(output_details).to.path('./results/top_posts_details.csv');
	
	fs.writeFile("./results/top_posts_details.json", JSON.stringify(output_details), function(err) {
    if (err) throw err;
    console.log('complete');
    });
	
	console.log(output_other); // list other output
	objOther.from.array(output_other).to.path('./results/other_posts.csv');
	
	fs.writeFile("./results/other_posts.json", JSON.stringify(output_other), function(err) {
    if (err) throw err;
    console.log('complete');
    });
	
	console.log(output_other_details); // list other output details
	objOtherDetails.from.array(output_other_details).to.path('./results/other_posts_details.csv');	
	
	fs.writeFile("./results/other_posts_details.json", JSON.stringify(output_other_details), function(err) {
    if (err) throw err;
    console.log('complete');
    });
	
	console.log("count: " + count); // count 
	console.log("other count: " + count_other); // count_other 

	var fromLine = {};
	var output_full_details_daily_tops = [];
	
	var max = -Infinity;
	var day_index = -Infinity;
	
	
	for(var index = 0; output_human_date.length > index; index++){	
		day_index = String(output_human_date[index]);			
		for(var pos = 0; output_full_details.length > pos; pos++){											
			var position_date = String(datetime.create(output_full_details[pos].timestamp).format('Y-m-d'));								
			if (day_index == position_date){					
				if (parseInt(output_full_details[pos].likes) > max){
					max = output_full_details[pos].likes;						
				}					
			}              			
		}
		output_max_values.push(max);			
		max = -Infinity;
	} 
			
	var fromLine1 = {};
	var fromLine2 = {};
	var fromLine3 = {};
	var fromLine4 = {};
	var fromLine5 = {};
	var fromLine6 = {};
	var fromLine7 = {};
	var fromLine8 = {};
	var fromLine9 = {};
	var fromLine10 = {};
	var fromLine11 = {};
	var fromLine12 = {};
	var fromLine13 = {};
	var fromLine14 = {};
	var fromLine15 = {};
	var fromLine16 = {};
	var fromLine17 = {};
	var fromLine18 = {};
	var fromLine19 = {};
	fromLine1.likes = output_max_values[0];
    fromLine1.timestamp = String(output_human_date[0]);	
	fromLine2.likes = output_max_values[1];
    fromLine2.timestamp = String(output_human_date[1]);
	fromLine3.likes = output_max_values[2];
    fromLine3.timestamp = String(output_human_date[2]);	
	fromLine4.likes = output_max_values[3];
    fromLine4.timestamp = String(output_human_date[3]);
	fromLine5.likes = output_max_values[4];
    fromLine5.timestamp = String(output_human_date[4]);	
	fromLine6.likes = output_max_values[5];
    fromLine6.timestamp = String(output_human_date[5]);
	fromLine7.likes = output_max_values[6];
    fromLine7.timestamp = String(output_human_date[6]);	
	fromLine8.likes = output_max_values[7];
    fromLine8.timestamp = String(output_human_date[7]);
	fromLine9.likes = output_max_values[8];
    fromLine9.timestamp = String(output_human_date[8]);
	fromLine10.likes = output_max_values[9];
    fromLine10.timestamp = String(output_human_date[9]);	
	fromLine11.likes = output_max_values[10];
    fromLine11.timestamp = String(output_human_date[10]);
	fromLine12.likes = output_max_values[11];
    fromLine12.timestamp = String(output_human_date[11]);	
	fromLine13.likes = output_max_values[12];
    fromLine13.timestamp = String(output_human_date[12]);
	fromLine14.likes = output_max_values[13];
    fromLine14.timestamp = String(output_human_date[13]);	
	fromLine15.likes = output_max_values[14];
    fromLine15.timestamp = String(output_human_date[14]);
	fromLine16.likes = output_max_values[15];
    fromLine16.timestamp = String(output_human_date[15]);	
	fromLine17.likes = output_max_values[16];
    fromLine17.timestamp = String(output_human_date[16]);
	fromLine18.likes = output_max_values[17];
    fromLine18.timestamp = String(output_human_date[17]);
	fromLine19.likes = output_max_values[18];
    fromLine19.timestamp = String(output_human_date[18]);
	output_full_details_daily_tops.push(fromLine1, fromLine2, fromLine3, fromLine4, fromLine5, fromLine6, fromLine7, fromLine8, fromLine9,
	                                    fromLine10, fromLine11, fromLine12, fromLine13, fromLine14, fromLine15, fromLine16, fromLine17, fromLine18,
										fromLine19); 
		
	console.log(output_full_details_daily_tops);
	
	objDailyTopPosts.from.array(output_full_details_daily_tops).to.path('./results/daily_top_posts.csv');	
	
	fs.writeFile("./results/daily_top_posts.json", JSON.stringify(output_full_details_daily_tops), function(err) {
    if (err) throw err;
    console.log('complete');
    });
		
});

